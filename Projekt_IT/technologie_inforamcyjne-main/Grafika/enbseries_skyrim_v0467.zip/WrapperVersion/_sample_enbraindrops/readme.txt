if you need custom rain texture, put one of these in to root folder of game and rename it
to enbraindrops.tga (or create your own ARGB texture). Original game textures ignored
completely when rain enabled in ENBSeries.